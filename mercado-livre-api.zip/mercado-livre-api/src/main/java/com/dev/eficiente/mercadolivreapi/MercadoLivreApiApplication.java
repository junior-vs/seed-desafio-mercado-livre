package com.dev.eficiente.mercadolivreapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MercadoLivreApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MercadoLivreApiApplication.class, args);
	}

}
